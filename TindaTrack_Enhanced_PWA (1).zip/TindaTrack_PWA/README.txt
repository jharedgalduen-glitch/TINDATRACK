TINDATRACK - INSTALLABLE PWA

FILES
- index.html: the TindaTrack application
- manifest.webmanifest: app name and home-screen icon settings
- sw.js: caches the app shell for offline opening after the first successful online load
- icon.svg: app icon

INSTALL ON ANDROID
1. Upload all files in this folder to the root of a public HTTPS website (for example, GitHub Pages).
2. Open the published HTTPS URL in Chrome on Android.
3. Tap the three-dot menu, then choose Install app, or Add to Home screen.
4. Open TindaTrack once online so the app shell is cached. Then test airplane mode.

IMPORTANT
- PWA install and service workers require HTTPS or localhost. Opening index.html directly from the file manager does not enable PWA install/offline caching.
- Records are stored in local browser storage on that device. Export backups regularly. Data does not automatically sync between devices.
- Camera barcode scanning may need internet access to load its barcode library the first time.

PRODUCT PHOTOS
- Open Products and add a product first. Then tap the 📷 Photo button on its product card.
- Choose an image from the phone gallery or camera. The app resizes it before saving locally.

SUPPLIERS
- Open Suppliers and enter the supplier name, contact number, and address/notes, then tap Save supplier.
- Saved suppliers appear in the list and as suggestions on the Stock in screen. Tap Use for stock to fill the stock-in supplier.

Always test sales, inventory, supplier records, and backups with sample data before using the app for real transactions.
